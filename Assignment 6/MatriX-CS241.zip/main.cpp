#include <iostream>
#include<string.h>

using namespace std;

void Mult2(int A[][4], int B[][4], int C[][4]);
void Print(int A[][4]);

int main()
{
  int A[4][4], B[4][4], C[4][4];
  int i,j;
  cout<<"Enter the elements of matrix A\n";
  
  for(i = 0; i < 4; i+=1)
  for(int j = 0; j<4; j+=1)
  {
    cin >> A[i][j];
  }
  
  cout << "Enter the elements of matrix B\n";
  
  for(int i = 0; i < 4; i+=1)
  for(j = 0; j < 4; j+=1)
  {
    cin >> B[i][j];
  }
  
  cout << "The product of\n";
  Print(A);
  
  cout << "and\n";
  Print(B);
  
  cout << "is\n";
  
  Mult2(A,B,C);
  
  Print(C);
  return 0;

}


void Print(int A[][4])
{
  int i,j;
  
  for(i = 0; i < 4 ; i++)
  {
    
    for(j = 0; j < 4; j++)
    {
      cout << A[i][j] << " ";
    }
    
    cout << "\n";
  }
}




void Mult2(int A[][4], int B[][4], int C[][4])
{
  int i,j,k,sum = 0;
  
  for (i = 0; i < 4; i++) 
  {
    for (j = 0; j < 4; j++) 
    {
      for (k = 0; k < 4; k++) 
      {
        sum = sum + A[i][k] * B[k][j];
      }
      
      C[i][j] = sum;
      sum = 0;
    }
  }

}
