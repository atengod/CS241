#include<iostream>
#include<fstream>
#include<string>
using namespace std;

int Perm3()
{
  ofstream ofile;
  ofile.open ("text.txt");
  
  for(char ch1 = 'a'; ch1 <= 'z'; ch1++)
  {
    for(char ch2 = 'a'; ch2 <= 'z'; ch2++)
    {
      if (ch2 == ch1) continue;
      
      for(char ch3 = 'a'; ch3 <= 'z'; ch3++)
      {
        if (ch3 == ch1) continue;
        if (ch3 == ch2) continue;
        ofile << ch1 << ch2 << ch3 << endl;
        
      }
      
    }
    
  }
  
  cout << "Data written to file" << endl;
  
  ofile.close();
  
  return 0;
  
}

int main() 
{
  Perm3();
  return 0;
  
}