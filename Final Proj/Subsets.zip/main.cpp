#include<iostream>
#include<stdio.h>
#include<string.h>

using namespace std;


char arr[100];

static int cnt = 0;

void powerSet(int n,char inp[],int k,int i)
{
  int j;
  
  if(n == 0)
  {
    printf("%d ) ",cnt);
    arr[i] = '\0';
    
    if(strlen(arr) == 0)
    printf("{ }");
    
    else
    printf(" %s",arr);
    printf("\n");
    cnt++;
    
  }
  
  else
  {
    powerSet(n-1, inp, k+1, i);
    arr[i] = inp[k];
    powerSet(n-1, inp, k+1, i+1);
    
  }
  
}

int main()
{
  int n;
  cout << "Enter number of elements:";
  cin >> n;
  
  char inp[n+1];
  cout << "Enter " << n << " elements";
  
  for(int i=0; i<n; ++i)
  {
    cin >> inp[i];
    
  }
  
  inp[n] = '\0';
  powerSet(n, inp, 0, 0);
  
  return 1;
}